package com.example.myapp

class constants {

    companion object {
        const val BASE_URL = "https://fcm.googleapis.com"
        const val SERVER_KEY = "AAAAk2TrLLk:APA91bEvuyx2pKbn-fbZFCYi_3GjckPfypTfirPA8GL4OWKeth1OkVu5duO8a--XoWnoxsrbeMXe107ZF2uuIkP4RcOljMOyH_ykacqdM2RfawiDT-SV5lfos7EaUaigewoDlGZWDM5B"
        const val CONTENT_TYPE = "aplication/json"
    }
}
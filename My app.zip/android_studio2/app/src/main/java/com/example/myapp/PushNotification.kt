package com.example.myapp

data class PushNotification(
    val data: NotificationData,
    val to: String
)